<?php
return array(
	'open_error'            => '<p class="form_error">',
	'close_error'           => '</p>',
);