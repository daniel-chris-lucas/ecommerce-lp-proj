<?php
return array(
	'crypto_key' => 'b6kwIc5CoVFsmlon6YQV46eI',
	'crypto_iv' => 'InwHREp48xwUkEM3n0v4IjtY',
	'crypto_hmac' => 'zLYTrI8TE7tQpZM3FEd0s5ms',
);
