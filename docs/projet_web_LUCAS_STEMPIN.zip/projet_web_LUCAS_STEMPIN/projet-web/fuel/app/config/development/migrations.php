<?php
return array(
	'version' => 
	array(
		'app' => 
		array(
			'default' => 
			array(
				0 => '001_create_countries',
				1 => '002_create_roles',
				2 => '003_create_users',
				3 => '004_create_categories',
				4 => '005_create_products',
				5 => '006_create_characteristics',
				6 => '007_create_images',
				7 => '008_create_ratings',
				8 => '009_create_options',
				9 => '010_create_mailsubscribers',
				10 => '011_create_orders',
				11 => '012_create_orderproducts',
				12 => '013_add_slug_to_categories',
				13 => '014_add_folder_to_images',
				14 => '015_add_slug_to_products',
				15 => '016_add_quantity_to_orderproducts',
				16 => '017_add_total_to_orders',
			),
		),
		'module' => 
		array(
		),
		'package' => 
		array(
		),
	),
	'folder' => 'migrations/',
	'table' => 'migration',
);
