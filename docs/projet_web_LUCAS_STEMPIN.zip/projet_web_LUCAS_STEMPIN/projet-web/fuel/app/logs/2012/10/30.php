<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

Error - 2012-10-30 13:06:29 --> Error - Call to undefined function age_from_dob() in L:\Local Server\sites\sandbox\projet-web\fuel\app\views\admin\users\index.php on line 18
Error - 2012-10-30 13:07:06 --> 8 - Undefined variable: dob in L:\Local Server\sites\sandbox\projet-web\fuel\app\classes\model\user.php on line 48
Error - 2012-10-30 13:12:34 --> Error - Property "role_name" not found for Model_User. in L:\Local Server\sites\sandbox\projet-web\fuel\packages\orm\classes\model.php on line 902
Error - 2012-10-30 13:14:51 --> Compile Error - Cannot redeclare Model_User::$_belongs_to in L:\Local Server\sites\sandbox\projet-web\fuel\app\classes\model\user.php on line 58
Error - 2012-10-30 13:14:59 --> Compile Error - Cannot redeclare Model_User::$_belongs_to in L:\Local Server\sites\sandbox\projet-web\fuel\app\classes\model\user.php on line 58
Error - 2012-10-30 13:52:55 --> Error - The requested view could not be found: admin/users/edit in L:\Local Server\sites\sandbox\projet-web\fuel\core\classes\view.php on line 381
Error - 2012-10-30 14:35:12 --> 4096 - Object of class Model_User could not be converted to string in L:\Local Server\sites\sandbox\projet-web\fuel\app\classes\controller\admin\users.php on line 156
Error - 2012-10-30 14:38:49 --> 8 - Trying to get property of non-object in L:\Local Server\sites\sandbox\projet-web\fuel\app\classes\controller\admin\base.php on line 34
Error - 2012-10-30 14:39:23 --> 8 - Trying to get property of non-object in L:\Local Server\sites\sandbox\projet-web\fuel\app\classes\controller\admin\base.php on line 34
Error - 2012-10-30 16:12:28 --> Error - Class 'PhpErrorException' not found in L:\Local Server\sites\sandbox\projet-web\fuel\app\classes\model\country.php on line 22
Error - 2012-10-30 16:13:09 --> Error - Class 'PhpErrorException' not found in L:\Local Server\sites\sandbox\projet-web\fuel\app\classes\model\country.php on line 21
Error - 2012-10-30 16:13:26 --> Error - Class 'PhpErrorException' not found in L:\Local Server\sites\sandbox\projet-web\fuel\app\classes\model\country.php on line 21
Error - 2012-10-30 16:15:40 --> Error - Class 'PhpErrorException' not found in L:\Local Server\sites\sandbox\projet-web\fuel\app\classes\model\country.php on line 19
Error - 2012-10-30 16:18:56 --> 4096 - Object of class Fuel\Core\Database_Result_Cached could not be converted to string in L:\Local Server\sites\sandbox\projet-web\fuel\app\classes\controller\admin\countries.php on line 9
Error - 2012-10-30 16:20:58 --> 8 - Undefined variable: result_arr in L:\Local Server\sites\sandbox\projet-web\fuel\app\classes\model\country.php on line 17
Error - 2012-10-30 16:21:02 --> 8 - Undefined variable: result_arr in L:\Local Server\sites\sandbox\projet-web\fuel\app\classes\model\country.php on line 17
Error - 2012-10-30 16:25:47 --> Error - Arr::merge() - all arguments must be arrays. in L:\Local Server\sites\sandbox\projet-web\fuel\core\classes\arr.php on line 755
Error - 2012-10-30 16:29:30 --> Error - Arr::merge() - all arguments must be arrays. in L:\Local Server\sites\sandbox\projet-web\fuel\core\classes\arr.php on line 755
Error - 2012-10-30 16:36:11 --> 8 - Trying to get property of non-object in L:\Local Server\sites\sandbox\projet-web\fuel\app\views\admin\countries\index.php on line 15
Error - 2012-10-30 16:37:01 --> 8 - Trying to get property of non-object in L:\Local Server\sites\sandbox\projet-web\fuel\app\views\admin\countries\index.php on line 15
Error - 2012-10-30 16:37:12 --> 8 - Trying to get property of non-object in L:\Local Server\sites\sandbox\projet-web\fuel\app\views\admin\countries\index.php on line 15
Error - 2012-10-30 16:43:02 --> Error - Database results are read-only in L:\Local Server\sites\sandbox\projet-web\fuel\core\classes\database\result.php on line 266
Error - 2012-10-30 16:43:18 --> Error - Call to undefined method Fuel\Core\Database_Result_Cached::as_obj() in L:\Local Server\sites\sandbox\projet-web\fuel\app\classes\controller\admin\countries.php on line 21
Error - 2012-10-30 16:43:26 --> Error - Call to undefined method Fuel\Core\Database_Result_Cached::as_object() in L:\Local Server\sites\sandbox\projet-web\fuel\app\classes\controller\admin\countries.php on line 21
Error - 2012-10-30 16:49:11 --> Error - Database results are read-only in L:\Local Server\sites\sandbox\projet-web\fuel\core\classes\database\result.php on line 266
Error - 2012-10-30 16:50:14 --> Error - Database results are read-only in L:\Local Server\sites\sandbox\projet-web\fuel\core\classes\database\result.php on line 266
Error - 2012-10-30 16:50:16 --> Error - Database results are read-only in L:\Local Server\sites\sandbox\projet-web\fuel\core\classes\database\result.php on line 266
Error - 2012-10-30 16:51:09 --> Error - Database results are read-only in L:\Local Server\sites\sandbox\projet-web\fuel\core\classes\database\result.php on line 266
Error - 2012-10-30 16:51:56 --> Error - Database results are read-only in L:\Local Server\sites\sandbox\projet-web\fuel\core\classes\database\result.php on line 266
Error - 2012-10-30 16:52:11 --> Error - Database results are read-only in L:\Local Server\sites\sandbox\projet-web\fuel\core\classes\database\result.php on line 266
Error - 2012-10-30 16:57:06 --> 8 - Trying to get property of non-object in L:\Local Server\sites\sandbox\projet-web\fuel\app\views\admin\countries\index.php on line 14
Error - 2012-10-30 17:00:07 --> Error - Cannot use object of type stdClass as array in L:\Local Server\sites\sandbox\projet-web\fuel\app\views\admin\countries\index.php on line 16
Error - 2012-10-30 17:00:09 --> Error - Cannot use object of type stdClass as array in L:\Local Server\sites\sandbox\projet-web\fuel\app\views\admin\countries\index.php on line 16
Error - 2012-10-30 17:15:24 --> Error - Call to undefined method Fuel\Core\Database_Query_Builder_Select::get() in L:\Local Server\sites\sandbox\projet-web\fuel\app\classes\controller\admin\countries.php on line 20
Error - 2012-10-30 18:12:56 --> 8 - Undefined variable: num_countries in L:\Local Server\sites\sandbox\projet-web\fuel\app\config\pagination.php on line 4
Error - 2012-10-30 18:12:58 --> 8 - Undefined variable: num_countries in L:\Local Server\sites\sandbox\projet-web\fuel\app\config\pagination.php on line 4
Error - 2012-10-30 18:13:30 --> Error - Arr::merge() - all arguments must be arrays. in L:\Local Server\sites\sandbox\projet-web\fuel\core\classes\arr.php on line 755
Error - 2012-10-30 18:33:58 --> 8 - Trying to get property of non-object in L:\Local Server\sites\sandbox\projet-web\fuel\app\classes\controller\admin\users.php on line 144
Error - 2012-10-30 20:47:03 --> Parsing Error - syntax error, unexpected 'echo' (T_ECHO) in L:\Local Server\sites\sandbox\projet-web\fuel\app\views\admin\categories\create.php on line 4
Error - 2012-10-30 20:52:31 --> Error - Property "parent" not found for Model_Category. in L:\Local Server\sites\sandbox\projet-web\fuel\packages\orm\classes\model.php on line 954
Error - 2012-10-30 20:52:50 --> Error - Property "parent" not found for Model_Category. in L:\Local Server\sites\sandbox\projet-web\fuel\packages\orm\classes\model.php on line 902
Error - 2012-10-30 20:54:20 --> 8 - Undefined variable: actegory in L:\Local Server\sites\sandbox\projet-web\fuel\app\classes\controller\admin\categories.php on line 39
Error - 2012-10-30 20:56:22 --> Error - SQLSTATE[HY000]: General error: 1366 Incorrect integer value: '' for column 'parent_id' at row 1 with query: "INSERT INTO `categories` (`name`, `parent_id`) VALUES ('Books', '')" in L:\Local Server\sites\sandbox\projet-web\fuel\core\classes\database\pdo\connection.php on line 175
Error - 2012-10-30 20:59:39 --> Error - SQLSTATE[HY000]: General error: 1366 Incorrect integer value: '' for column 'parent_id' at row 1 with query: "INSERT INTO `categories` (`name`, `parent_id`) VALUES ('Books', '')" in L:\Local Server\sites\sandbox\projet-web\fuel\core\classes\database\pdo\connection.php on line 175
Error - 2012-10-30 21:00:00 --> Error - SQLSTATE[HY000]: General error: 1366 Incorrect integer value: '' for column 'parent_id' at row 1 with query: "INSERT INTO `categories` (`name`, `parent_id`) VALUES ('Books', '')" in L:\Local Server\sites\sandbox\projet-web\fuel\core\classes\database\pdo\connection.php on line 175
Error - 2012-10-30 21:04:40 --> Error - SQLSTATE[HY000]: General error: 1366 Incorrect integer value: 'null' for column 'parent_id' at row 1 with query: "INSERT INTO `categories` (`name`, `parent_id`) VALUES ('Books', 'null')" in L:\Local Server\sites\sandbox\projet-web\fuel\core\classes\database\pdo\connection.php on line 175
Error - 2012-10-30 21:07:06 --> Error - Property "parent" not found for Model_Category. in L:\Local Server\sites\sandbox\projet-web\fuel\packages\orm\classes\model.php on line 902
Error - 2012-10-30 21:07:16 --> 8 - Trying to get property of non-object in L:\Local Server\sites\sandbox\projet-web\fuel\app\views\admin\categories\index.php on line 15
Error - 2012-10-30 21:19:42 --> Error - Call to undefined method Orm\Query::group_by() in L:\Local Server\sites\sandbox\projet-web\fuel\app\classes\controller\admin\categories.php on line 37
Error - 2012-10-30 21:26:34 --> 8 - Use of undefined constant asc - assumed 'asc' in L:\Local Server\sites\sandbox\projet-web\fuel\app\classes\controller\admin\categories.php on line 46
Error - 2012-10-30 21:26:49 --> Error - Database results are read-only in L:\Local Server\sites\sandbox\projet-web\fuel\core\classes\database\result.php on line 266
Error - 2012-10-30 21:32:32 --> Error - Call to undefined method Orm\Query::group_by() in L:\Local Server\sites\sandbox\projet-web\fuel\app\classes\controller\admin\categories.php on line 37
