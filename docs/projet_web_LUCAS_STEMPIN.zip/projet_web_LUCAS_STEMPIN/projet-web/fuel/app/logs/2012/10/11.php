<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

Warning - 2012-10-11 12:33:57 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-11 12:55:40 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-11 12:55:40 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
