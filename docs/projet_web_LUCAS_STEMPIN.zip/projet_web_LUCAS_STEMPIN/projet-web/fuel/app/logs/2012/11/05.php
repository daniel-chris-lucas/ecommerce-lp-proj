<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

Error - 2012-11-05 14:28:04 --> Error - Call to undefined method Fuel\Core\Validation::add_rule() in L:\Local Server\sites\sandbox\projet-web\fuel\app\classes\controller\admin\products.php on line 36
Error - 2012-11-05 14:28:19 --> 2 - Creating default object from empty value in L:\Local Server\sites\sandbox\projet-web\fuel\app\classes\controller\admin\products.php on line 45
Error - 2012-11-05 14:28:33 --> 2 - Creating default object from empty value in L:\Local Server\sites\sandbox\projet-web\fuel\app\classes\controller\admin\products.php on line 45
Error - 2012-11-05 14:29:05 --> 2 - Creating default object from empty value in L:\Local Server\sites\sandbox\projet-web\fuel\app\classes\controller\admin\products.php on line 44
