<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

Warning - 2012-10-20 17:35:07 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 17:41:56 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 17:45:58 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 17:46:15 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 17:46:20 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 17:46:21 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 17:46:22 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 17:46:54 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 17:47:59 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 17:50:52 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 17:50:54 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 17:50:55 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 17:50:56 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 17:53:27 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 17:55:13 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 17:55:14 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 17:56:11 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 17:56:44 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Error - 2012-10-20 17:56:44 --> Error - Could not find asset: bootstrap.css in L:\Local Server\sites\sandbox\projet-web\fuel\core\classes\asset\instance.php on line 248
Warning - 2012-10-20 17:57:51 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 17:59:32 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 18:00:07 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 18:04:02 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 18:04:49 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 18:04:50 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 18:04:52 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 18:04:53 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 18:05:09 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Error - 2012-10-20 18:05:09 --> Compile Error - Can't use function return value in write context in L:\Local Server\sites\sandbox\projet-web\fuel\app\views\layouts\template.php on line 91
Warning - 2012-10-20 18:05:10 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Error - 2012-10-20 18:05:10 --> Compile Error - Can't use function return value in write context in L:\Local Server\sites\sandbox\projet-web\fuel\app\views\layouts\template.php on line 91
Warning - 2012-10-20 18:05:11 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Error - 2012-10-20 18:05:11 --> Compile Error - Can't use function return value in write context in L:\Local Server\sites\sandbox\projet-web\fuel\app\views\layouts\template.php on line 91
Warning - 2012-10-20 18:05:11 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Error - 2012-10-20 18:05:11 --> Compile Error - Can't use function return value in write context in L:\Local Server\sites\sandbox\projet-web\fuel\app\views\layouts\template.php on line 91
Warning - 2012-10-20 18:05:12 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Error - 2012-10-20 18:05:12 --> Compile Error - Can't use function return value in write context in L:\Local Server\sites\sandbox\projet-web\fuel\app\views\layouts\template.php on line 91
Warning - 2012-10-20 18:05:12 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Error - 2012-10-20 18:05:12 --> Compile Error - Can't use function return value in write context in L:\Local Server\sites\sandbox\projet-web\fuel\app\views\layouts\template.php on line 91
Warning - 2012-10-20 18:06:33 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 18:06:44 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 18:09:37 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 18:09:38 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 18:09:39 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 18:09:40 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 18:09:42 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 18:09:42 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 18:09:43 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 18:09:52 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 18:10:14 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 18:10:21 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 18:10:29 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 18:12:42 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 18:14:55 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 18:14:56 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 18:15:42 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 18:17:36 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 18:17:37 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 18:17:38 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 18:17:38 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 18:17:39 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 18:17:39 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 18:17:39 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 18:17:39 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 18:17:39 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 18:17:40 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 18:17:47 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 18:17:50 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 18:18:15 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 18:18:19 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 18:19:09 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 18:22:13 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 18:22:30 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 18:23:03 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 18:23:18 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 18:23:33 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 18:24:38 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 18:26:14 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 18:26:25 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 18:28:07 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 18:28:08 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 18:28:09 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 18:28:15 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 18:28:55 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 18:28:57 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 18:31:36 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 18:32:46 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 18:32:47 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 18:32:48 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 18:34:20 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 18:35:50 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 18:35:51 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 18:35:51 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 18:35:52 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 18:35:59 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 18:35:59 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 18:36:00 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 18:36:01 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 18:36:01 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 18:36:01 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 18:36:02 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 18:36:14 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 18:36:15 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 18:36:15 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 18:36:16 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 18:40:46 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 18:41:29 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 18:41:30 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 18:41:31 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 18:41:31 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 18:41:31 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 18:41:31 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 18:41:32 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 18:42:38 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 18:42:39 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 18:42:39 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 18:42:40 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 18:42:40 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 18:42:41 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 18:43:39 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 18:43:39 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 18:43:40 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 18:43:41 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 18:44:26 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 18:44:27 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 18:44:28 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 18:45:04 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 18:45:08 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 18:52:09 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 18:52:37 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 18:54:30 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 18:55:16 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 18:58:46 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 18:59:08 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 18:59:09 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 19:02:00 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 19:04:07 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 19:04:42 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 19:05:31 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 19:06:38 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 19:06:46 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 19:07:55 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 19:22:37 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 19:26:29 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 19:43:52 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 19:48:02 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 19:48:25 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 19:48:28 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 19:48:40 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 19:49:26 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 19:49:27 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 19:52:43 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Error - 2012-10-20 19:52:43 --> 2 - implode(): Invalid arguments passed in L:\Local Server\sites\sandbox\projet-web\fuel\app\classes\controller\users.php on line 59
Warning - 2012-10-20 19:54:05 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Error - 2012-10-20 19:54:05 --> 8 - Undefined variable: birth_months in L:\Local Server\sites\sandbox\projet-web\fuel\app\views\users\register.php on line 19
Warning - 2012-10-20 19:54:30 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Error - 2012-10-20 19:54:30 --> 8 - Undefined variable: birth_month_v in L:\Local Server\sites\sandbox\projet-web\fuel\app\views\users\register.php on line 20
Warning - 2012-10-20 19:54:52 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 19:55:30 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 19:57:30 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 19:58:10 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 19:58:48 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 20:00:06 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 20:01:14 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 20:01:44 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 20:02:44 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 20:03:16 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 20:04:01 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 20:04:28 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 20:05:17 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 20:06:09 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 20:07:37 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 20:10:42 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 20:11:23 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 20:18:34 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Error - 2012-10-20 20:18:34 --> Error - Invalid method call.  Method fetch_all does not exist. in L:\Local Server\sites\sandbox\projet-web\fuel\packages\orm\classes\model.php on line 560
Warning - 2012-10-20 20:21:45 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 20:22:04 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 20:22:21 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 20:23:25 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 20:23:49 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 20:25:50 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Error - 2012-10-20 20:25:51 --> 4096 - Object of class Model_Country could not be converted to string in L:\Local Server\sites\sandbox\projet-web\fuel\app\views\users\register.php on line 45
Warning - 2012-10-20 20:27:15 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 20:28:53 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Error - 2012-10-20 20:28:53 --> Error - SQLSTATE[42S22]: Column not found: 1054 Unknown column 't0.order_by' in 'field list' with query: "SELECT `t0`.`order_by` AS `t0_c0`, `t0`.`id` AS `t0_c1` FROM `countries` AS `t0`" in L:\Local Server\sites\sandbox\projet-web\fuel\core\classes\database\pdo\connection.php on line 175
Warning - 2012-10-20 20:29:04 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 20:39:31 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 20:41:41 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 20:44:25 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 20:45:01 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 20:45:10 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 20:47:29 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 20:48:03 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Error - 2012-10-20 20:48:03 --> Error - Object class "Fuel\Core\Validation" could not be converted to string or sanitized as ArrayAccess. Whitelist it in security.whitelisted_classes in app/config/config.php to allow it to be passed unchecked. in L:\Local Server\sites\sandbox\projet-web\fuel\core\classes\security.php on line 232
Warning - 2012-10-20 20:48:51 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 20:48:57 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 20:49:04 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 20:51:14 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 20:51:22 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 20:51:44 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 20:55:44 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-20 20:55:49 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Error - 2012-10-20 21:17:16 --> 2 - preg_match(): No ending matching delimiter ')' found in L:\Local Server\sites\sandbox\projet-web\fuel\core\classes\validation.php on line 692
Error - 2012-10-20 21:28:08 --> 8 - Undefined variable: birth_month in L:\Local Server\sites\sandbox\projet-web\fuel\app\views\users\register.php on line 31
Error - 2012-10-20 21:46:42 --> 2 - Creating default object from empty value in L:\Local Server\sites\sandbox\projet-web\fuel\app\classes\controller\users.php on line 79
Error - 2012-10-20 21:48:04 --> Error - Call to undefined method Model_User::validated() in L:\Local Server\sites\sandbox\projet-web\fuel\packages\orm\classes\model.php on line 1664
Error - 2012-10-20 21:51:08 --> Error - Property "birth_day" not found for Model_User. in L:\Local Server\sites\sandbox\projet-web\fuel\packages\orm\classes\model.php on line 954
Error - 2012-10-20 22:01:08 --> 2 - implode(): Argument must be an array in L:\Local Server\sites\sandbox\projet-web\fuel\app\classes\controller\users.php on line 83
Error - 2012-10-20 22:27:41 --> 8 - Array to string conversion in L:\Local Server\sites\sandbox\projet-web\fuel\app\classes\controller\users.php on line 86
Error - 2012-10-20 22:28:25 --> 8 - Undefined index: id in L:\Local Server\sites\sandbox\projet-web\fuel\app\classes\controller\users.php on line 84
Error - 2012-10-20 22:38:08 --> Error - SQLSTATE[HY000]: General error: 1366 Incorrect integer value: '' for column 'street_number' at row 1 with query: "INSERT INTO `users` (`username`, `password`, `first_name`, `last_name`, `date_of_birth`, `street`, `street_number`, `town`, `country_id`, `tel`, `email`, `role_id`, `confirmation_code`, `activated`, `created_at`, `updated_at`) VALUES ('xonorageous', 'mRl_Ig9gwj6oXfqkTy2e_WR4dXBhSUh5UzZxYU9wbG5LazExa3Z1N1F2QTJORjZV', 'Daniel', 'Lucas', '10-4-1990', 'Le Grippe', '', 'St Dolay', '76', '', 'daniel.chris.lucas@gmail.com', '1', 'OaOs0uYzLoE5ohaN', 0, 1350772688, 1350772688)" in L:\Local Server\sites\sandbox\projet-web\fuel\core\classes\database\pdo\connection.php on line 175
Error - 2012-10-20 23:32:39 --> Error - Undefined class constant 'method' in L:\Local Server\sites\sandbox\projet-web\fuel\app\classes\controller\users.php on line 76
