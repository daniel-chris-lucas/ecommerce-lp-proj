<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

Error - 2012-11-07 13:55:37 --> Error - Function imagecreatefromjpeg() does not exist (Missing GD?) in L:\Local Server\sites\sandbox\projet-web\fuel\core\classes\image\gd.php on line 56
Error - 2012-11-07 14:30:38 --> Error - Function imagecreatefromjpeg() does not exist (Missing GD?) in L:\Local Server\sites\sandbox\projet-web\fuel\core\classes\image\gd.php on line 56
Error - 2012-11-07 14:32:53 --> 4096 - Object of class Fuel\Core\Image_Gd could not be converted to string in L:\Local Server\sites\sandbox\projet-web\fuel\app\classes\controller\admin\products.php on line 118
Error - 2012-11-07 19:29:08 --> 23000 - SQLSTATE[23000]: Integrity constraint violation: 1048 Column 'alt' cannot be null with query: "INSERT INTO `images` (`name`, `alt`, `product_id`) VALUES ('Books/73cbd8d5f052a59e7ef4c8d892cf5a68.jpg', null, '1')" in L:\Local Server\sites\sandbox\projet-web\fuel\core\classes\database\pdo\connection.php on line 175
Error - 2012-11-07 19:29:35 --> 23000 - SQLSTATE[23000]: Integrity constraint violation: 1048 Column 'alt' cannot be null with query: "INSERT INTO `images` (`name`, `alt`, `product_id`) VALUES ('Books/840417aa384ecd8a7df8130ec7cf9d13.jpg', null, '1')" in L:\Local Server\sites\sandbox\projet-web\fuel\core\classes\database\pdo\connection.php on line 175
Error - 2012-11-07 19:34:47 --> Error - Cannot access protected property Fuel\Core\Image_Gd::$image_filename in L:\Local Server\sites\sandbox\projet-web\fuel\app\classes\controller\admin\products.php on line 122
Error - 2012-11-07 19:40:16 --> Error - Property "filename" not found for Model_Image. in L:\Local Server\sites\sandbox\projet-web\fuel\packages\orm\classes\model.php on line 902
Error - 2012-11-07 19:43:56 --> Parsing Error - syntax error, unexpected 'Upload' (T_STRING) in L:\Local Server\sites\sandbox\projet-web\fuel\app\classes\controller\admin\products.php on line 106
Error - 2012-11-07 19:44:01 --> Parsing Error - syntax error, unexpected 'Upload' (T_STRING) in L:\Local Server\sites\sandbox\projet-web\fuel\app\classes\controller\admin\products.php on line 106
Error - 2012-11-07 19:53:08 --> Error - Property "category_name" not found for Model_Product. in L:\Local Server\sites\sandbox\projet-web\fuel\packages\orm\classes\model.php on line 902
Error - 2012-11-07 19:59:21 --> 4096 - Object of class Fuel\Core\Image_Gd could not be converted to string in L:\Local Server\sites\sandbox\projet-web\fuel\app\classes\controller\admin\products.php on line 120
