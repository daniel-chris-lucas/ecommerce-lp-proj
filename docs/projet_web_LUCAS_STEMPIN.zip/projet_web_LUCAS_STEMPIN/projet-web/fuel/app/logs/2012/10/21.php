<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

Error - 2012-10-21 07:44:07 --> Error - Call to a member function exit() on a non-object in L:\Local Server\sites\sandbox\projet-web\fuel\app\classes\controller\users.php on line 40
Error - 2012-10-21 08:35:39 --> Compile Error - Can't use function return value in write context in L:\Local Server\sites\sandbox\projet-web\fuel\app\classes\controller\users.php on line 218
Error - 2012-10-21 09:16:48 --> Parsing Error - syntax error, unexpected ')', expecting ',' or ';' in L:\Local Server\sites\sandbox\projet-web\fuel\app\views\home\contact.php on line 21
Error - 2012-10-21 09:18:44 --> Error - Call to undefined function find_file() in L:\Local Server\sites\sandbox\projet-web\fuel\app\views\home\contact.php on line 21
Error - 2012-10-21 10:45:14 --> Parsing Error - syntax error, unexpected 'email' (T_STRING) in L:\Local Server\sites\sandbox\projet-web\fuel\app\classes\controller\home.php on line 39
Error - 2012-10-21 10:45:29 --> Parsing Error - syntax error, unexpected ',', expecting ')' in L:\Local Server\sites\sandbox\projet-web\fuel\app\classes\controller\home.php on line 40
Error - 2012-10-21 11:04:23 --> 8 - Undefined variable: title in L:\Local Server\sites\sandbox\projet-web\fuel\app\views\layouts\template.php on line 9
Error - 2012-10-21 11:04:55 --> 8 - Undefined variable: birth_days in L:\Local Server\sites\sandbox\projet-web\fuel\app\classes\controller\users.php on line 230
Error - 2012-10-21 11:05:35 --> Error - The requested view could not be found: users/account in L:\Local Server\sites\sandbox\projet-web\fuel\core\classes\view.php on line 381
Error - 2012-10-21 12:38:09 --> Error - One or more email addresses did not pass validation: to: daniel.chris.lucas.
 in L:\Local Server\sites\sandbox\projet-web\fuel\packages\email\classes\email\driver.php on line 671
Error - 2012-10-21 12:41:34 --> Error - Cannot send without from address. in L:\Local Server\sites\sandbox\projet-web\fuel\packages\email\classes\email\driver.php on line 654
Error - 2012-10-21 18:42:15 --> Error - Call to undefined method Fuel\Core\Validation::getMessage() in L:\Local Server\sites\sandbox\projet-web\fuel\app\views\users\register.php on line 12
Error - 2012-10-21 18:43:18 --> Error - Call to a member function getMessage() on a non-object in L:\Local Server\sites\sandbox\projet-web\fuel\app\views\users\register.php on line 12
Error - 2012-10-21 18:46:47 --> Error - Call to a member function getMessage() on a non-object in L:\Local Server\sites\sandbox\projet-web\fuel\app\views\users\register.php on line 12
Error - 2012-10-21 18:46:48 --> Error - Call to a member function getMessage() on a non-object in L:\Local Server\sites\sandbox\projet-web\fuel\app\views\users\register.php on line 12
Error - 2012-10-21 18:46:49 --> Error - Call to a member function getMessage() on a non-object in L:\Local Server\sites\sandbox\projet-web\fuel\app\views\users\register.php on line 12
Error - 2012-10-21 18:46:49 --> Error - Call to a member function getMessage() on a non-object in L:\Local Server\sites\sandbox\projet-web\fuel\app\views\users\register.php on line 12
Error - 2012-10-21 18:46:50 --> Error - Call to a member function getMessage() on a non-object in L:\Local Server\sites\sandbox\projet-web\fuel\app\views\users\register.php on line 12
Error - 2012-10-21 18:46:50 --> Error - Call to a member function getMessage() on a non-object in L:\Local Server\sites\sandbox\projet-web\fuel\app\views\users\register.php on line 12
Error - 2012-10-21 18:46:50 --> Error - Call to a member function getMessage() on a non-object in L:\Local Server\sites\sandbox\projet-web\fuel\app\views\users\register.php on line 12
Error - 2012-10-21 18:57:49 --> Error - Call to a member function get_message() on a non-object in L:\Local Server\sites\sandbox\projet-web\fuel\app\views\users\register.php on line 12
Error - 2012-10-21 19:46:17 --> Error - Property "country" not found for Model_User. in L:\Local Server\sites\sandbox\projet-web\fuel\packages\orm\classes\model.php on line 902
Error - 2012-10-21 20:34:25 --> Error - Relation "countries" was not found in the model. in L:\Local Server\sites\sandbox\projet-web\fuel\packages\orm\classes\query.php on line 524
Error - 2012-10-21 20:34:28 --> Error - Relation "countries" was not found in the model. in L:\Local Server\sites\sandbox\projet-web\fuel\packages\orm\classes\query.php on line 524
Error - 2012-10-21 20:34:41 --> Error - Relation "country" was not found in the model. in L:\Local Server\sites\sandbox\projet-web\fuel\packages\orm\classes\query.php on line 524
Error - 2012-10-21 20:34:48 --> Error - Relation "countries" was not found in the model. in L:\Local Server\sites\sandbox\projet-web\fuel\packages\orm\classes\query.php on line 524
Error - 2012-10-21 20:34:58 --> Error - Relation "countries" was not found in the model. in L:\Local Server\sites\sandbox\projet-web\fuel\packages\orm\classes\query.php on line 524
Error - 2012-10-21 21:05:20 --> Parsing Error - syntax error, unexpected ')' in L:\Local Server\sites\sandbox\projet-web\fuel\app\classes\controller\users.php on line 351
Error - 2012-10-21 21:05:22 --> Parsing Error - syntax error, unexpected ')' in L:\Local Server\sites\sandbox\projet-web\fuel\app\classes\controller\users.php on line 352
Error - 2012-10-21 21:05:49 --> Parsing Error - syntax error, unexpected ')' in L:\Local Server\sites\sandbox\projet-web\fuel\app\classes\controller\users.php on line 352
Error - 2012-10-21 21:06:57 --> 8 - Array to string conversion in L:\Local Server\sites\sandbox\projet-web\fuel\app\classes\controller\users.php on line 344
Error - 2012-10-21 21:07:17 --> Parsing Error - syntax error, unexpected ';' in L:\Local Server\sites\sandbox\projet-web\fuel\app\classes\controller\users.php on line 342
Error - 2012-10-21 21:25:19 --> 8 - Undefined variable: current_user in L:\Local Server\sites\sandbox\projet-web\fuel\app\classes\controller\users.php on line 303
Error - 2012-10-21 21:25:39 --> 8 - Undefined variable: password in L:\Local Server\sites\sandbox\projet-web\fuel\app\classes\controller\users.php on line 314
