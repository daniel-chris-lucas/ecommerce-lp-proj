<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

Error - 2012-11-28 13:55:11 --> Compile Error - Can't use function return value in write context in L:\Local Server\sites\sandbox\projet-web\fuel\app\classes\controller\products.php on line 53
Error - 2012-11-28 13:55:31 --> Error - Form instance already exists, cannot be recreated. Use instance() instead of factory() to retrieve the existing instance. in L:\Local Server\sites\sandbox\projet-web\fuel\core\classes\validation.php on line 57
Error - 2012-11-28 14:04:26 --> Error - Form instance already exists, cannot be recreated. Use instance() instead of factory() to retrieve the existing instance. in L:\Local Server\sites\sandbox\projet-web\fuel\core\classes\validation.php on line 57
Error - 2012-11-28 14:07:49 --> Error - Undefined class constant 'method' in L:\Local Server\sites\sandbox\projet-web\fuel\app\classes\controller\products.php on line 51
Error - 2012-11-28 14:10:06 --> 8 - Undefined variable: _SESSION in L:\Local Server\sites\sandbox\projet-web\fuel\app\classes\controller\products.php on line 8
Error - 2012-11-28 14:11:56 --> Error - Cannot use [] for reading in L:\Local Server\sites\sandbox\projet-web\fuel\app\classes\controller\products.php on line 60
Error - 2012-11-28 14:57:45 --> 2 - Invalid argument supplied for foreach() in L:\Local Server\sites\sandbox\projet-web\fuel\app\classes\controller\products.php on line 70
Error - 2012-11-28 15:24:23 --> 8 - Undefined variable: cart_total in L:\Local Server\sites\sandbox\projet-web\fuel\app\views\layouts\template.php on line 80
Error - 2012-11-28 15:26:00 --> 8 - Undefined index: price in L:\Local Server\sites\sandbox\projet-web\fuel\app\classes\controller\base.php on line 51
Error - 2012-11-28 15:36:07 --> 8 - Undefined variable: cart_total in L:\Local Server\sites\sandbox\projet-web\fuel\app\classes\controller\products.php on line 76
Error - 2012-11-28 15:36:49 --> 8 - Undefined index: price in L:\Local Server\sites\sandbox\projet-web\fuel\app\classes\controller\products.php on line 77
Error - 2012-11-28 15:37:01 --> 8 - Undefined index: price in L:\Local Server\sites\sandbox\projet-web\fuel\app\classes\controller\base.php on line 46
Error - 2012-11-28 15:38:01 --> 8 - Undefined index: price in L:\Local Server\sites\sandbox\projet-web\fuel\app\classes\controller\base.php on line 46
Error - 2012-11-28 15:38:37 --> 8 - Undefined variable: cart_total in L:\Local Server\sites\sandbox\projet-web\fuel\app\views\layouts\template.php on line 80
Error - 2012-11-28 16:01:20 --> 8 - Undefined variable: cart_total in L:\Local Server\sites\sandbox\projet-web\fuel\app\views\layouts\template.php on line 80
Error - 2012-11-28 16:03:13 --> 8 - Undefined index: price in L:\Local Server\sites\sandbox\projet-web\fuel\app\classes\controller\products.php on line 77
Error - 2012-11-28 16:05:07 --> 8 - Undefined index: price in L:\Local Server\sites\sandbox\projet-web\fuel\app\classes\controller\products.php on line 77
Error - 2012-11-28 16:06:02 --> 8 - Undefined index: price in L:\Local Server\sites\sandbox\projet-web\fuel\app\classes\controller\products.php on line 77
Error - 2012-11-28 16:06:05 --> 8 - Undefined index: price in L:\Local Server\sites\sandbox\projet-web\fuel\app\classes\controller\base.php on line 46
Error - 2012-11-28 16:07:02 --> 8 - Undefined index: price in L:\Local Server\sites\sandbox\projet-web\fuel\app\classes\controller\base.php on line 46
Error - 2012-11-28 16:10:42 --> 8 - Undefined variable: cart_total in L:\Local Server\sites\sandbox\projet-web\fuel\app\views\layouts\template.php on line 80
Error - 2012-11-28 17:12:11 --> 8 - Trying to get property of non-object in L:\Local Server\sites\sandbox\projet-web\fuel\app\views\products\shopping_cart.php on line 21
Error - 2012-11-28 17:13:06 --> 8 - Trying to get property of non-object in L:\Local Server\sites\sandbox\projet-web\fuel\app\views\products\shopping_cart.php on line 23
Error - 2012-11-28 17:21:34 --> 8 - Trying to get property of non-object in L:\Local Server\sites\sandbox\projet-web\fuel\app\classes\controller\products.php on line 100
Error - 2012-11-28 17:27:53 --> Parsing Error - syntax error, unexpected 'endif' (T_ENDIF) in L:\Local Server\sites\sandbox\projet-web\fuel\app\views\products\shopping_cart.php on line 28
Error - 2012-11-28 17:28:08 --> 8 - Trying to get property of non-object in L:\Local Server\sites\sandbox\projet-web\fuel\app\views\products\shopping_cart.php on line 21
Error - 2012-11-28 17:35:21 --> Error - Property "quantity" not found for Model_Product. in L:\Local Server\sites\sandbox\projet-web\fuel\packages\orm\classes\model.php on line 954
Error - 2012-11-28 17:36:07 --> Error - Property "quantity" not found for Model_Product. in L:\Local Server\sites\sandbox\projet-web\fuel\packages\orm\classes\model.php on line 902
