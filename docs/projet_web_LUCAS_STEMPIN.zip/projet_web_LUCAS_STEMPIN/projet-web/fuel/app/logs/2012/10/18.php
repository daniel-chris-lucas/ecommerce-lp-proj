<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

Warning - 2012-10-18 06:40:11 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-18 06:40:15 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-18 06:44:59 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-18 06:46:05 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-18 06:47:08 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-18 06:48:49 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-18 06:50:05 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-18 09:04:21 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-18 09:04:25 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-18 09:04:26 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-18 09:04:27 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
