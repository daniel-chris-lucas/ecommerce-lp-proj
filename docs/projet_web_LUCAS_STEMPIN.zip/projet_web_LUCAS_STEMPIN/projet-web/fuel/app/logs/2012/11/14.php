<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

Error - 2012-11-14 09:41:11 --> 8 - Undefined variable: _SESSION in L:\Local Server\sites\sandbox\projet-web\fuel\app\classes\controller\home.php on line 59
