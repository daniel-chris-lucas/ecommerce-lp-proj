<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

Error - 2012-11-13 09:25:46 --> Error - Call to undefined method Fuel\Core\Fieldset_Field::add_ruel() in L:\Local Server\sites\sandbox\projet-web\fuel\app\classes\controller\users.php on line 104
Error - 2012-11-13 09:31:13 --> 8 - Undefined variable: _SESSION in L:\Local Server\sites\sandbox\projet-web\fuel\app\classes\controller\users.php on line 115
Error - 2012-11-13 09:31:18 --> 8 - Undefined variable: _SESSION in L:\Local Server\sites\sandbox\projet-web\fuel\app\classes\controller\users.php on line 115
