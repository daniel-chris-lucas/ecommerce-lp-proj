<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

Error - 2012-11-29 07:16:51 --> Error - Property "quantity" not found for Model_Product. in L:\Local Server\sites\sandbox\projet-web\fuel\packages\orm\classes\model.php on line 954
Error - 2012-11-29 07:23:32 --> Error - Property "quantity" not found for Model_Product. in L:\Local Server\sites\sandbox\projet-web\fuel\packages\orm\classes\model.php on line 954
Error - 2012-11-29 07:27:14 --> 8 - Trying to get property of non-object in L:\Local Server\sites\sandbox\projet-web\fuel\app\classes\controller\products.php on line 107
Error - 2012-11-29 08:47:39 --> 8 - Undefined variable: subtotal in L:\Local Server\sites\sandbox\projet-web\fuel\app\views\products\shopping_cart.php on line 39
Error - 2012-11-29 09:32:36 --> 8 - Undefined variable: vat in L:\Local Server\sites\sandbox\projet-web\fuel\app\views\products\shopping_cart.php on line 50
Error - 2012-11-29 09:40:45 --> 2 - Attempt to modify property of non-object in L:\Local Server\sites\sandbox\projet-web\fuel\app\classes\controller\products.php on line 108
Error - 2012-11-29 09:41:42 --> 2 - Attempt to modify property of non-object in L:\Local Server\sites\sandbox\projet-web\fuel\app\classes\controller\products.php on line 108
Error - 2012-11-29 10:12:20 --> 8 - Undefined variable: filename in L:\Local Server\sites\sandbox\projet-web\fuel\app\classes\model\image.php on line 44
Error - 2012-11-29 10:13:48 --> 8 - Undefined variable: from in L:\Local Server\sites\sandbox\projet-web\fuel\app\classes\model\image.php on line 45
Error - 2012-11-29 13:27:58 --> 8 - Undefined index: location in L:\Local Server\sites\sandbox\projet-web\fuel\app\views\products\shopping_cart.php on line 36
Error - 2012-11-29 15:07:41 --> Parsing Error - syntax error, unexpected ')' in L:\Local Server\sites\sandbox\projet-web\fuel\app\classes\controller\products.php on line 95
Error - 2012-11-29 16:49:51 --> Error - Maximum execution time of 30 seconds exceeded in L:\Local Server\sites\sandbox\projet-web\fuel\core\classes\finder.php on line 343
