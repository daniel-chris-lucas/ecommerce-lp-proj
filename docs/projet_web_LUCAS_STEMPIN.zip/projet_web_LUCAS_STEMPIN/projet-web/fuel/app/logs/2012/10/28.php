<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

Warning - 2012-10-28 22:13:27 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
Warning - 2012-10-28 22:17:51 --> Fuel\Core\Fuel::init - The configured locale en_US is not installed on your system.
