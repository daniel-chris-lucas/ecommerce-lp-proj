<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

Error - 2012-12-14 23:41:49 --> 8 - Undefined property: Controller_Home::$main_category in L:\Local Server\sites\sandbox\projet-web\fuel\app\classes\controller\base.php on line 30
