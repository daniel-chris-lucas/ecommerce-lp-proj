<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

Error - 2012-11-26 18:56:22 --> 8 - Use of undefined constant php - assumed 'php' in L:\Local Server\sites\sandbox\projet-web\fuel\app\views\products\view.php on line 83
Error - 2012-11-26 19:27:31 --> 8 - Undefined variable: current_user in L:\Local Server\sites\sandbox\projet-web\fuel\app\classes\controller\products.php on line 33
Error - 2012-11-26 19:28:20 --> 8 - Trying to get property of non-object in L:\Local Server\sites\sandbox\projet-web\fuel\app\classes\controller\products.php on line 33
