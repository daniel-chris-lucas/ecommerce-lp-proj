<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

Error - 2012-12-03 10:06:08 --> Error - Maximum execution time of 30 seconds exceeded in L:\Local Server\sites\sandbox\projet-web\fuel\core\classes\error.php on line 228
Error - 2012-12-03 10:11:13 --> Error - Maximum execution time of 30 seconds exceeded in L:\Local Server\sites\sandbox\projet-web\fuel\core\classes\view.php on line 233
Error - 2012-12-03 10:11:18 --> Error - Maximum execution time of 30 seconds exceeded in L:\Local Server\sites\sandbox\projet-web\fuel\core\classes\view.php on line 379
Error - 2012-12-03 10:11:49 --> Error - Maximum execution time of 30 seconds exceeded in L:\Local Server\sites\sandbox\projet-web\fuel\core\classes\finder.php on line 343
Error - 2012-12-03 10:13:14 --> Error - Maximum execution time of 30 seconds exceeded in L:\Local Server\sites\sandbox\projet-web\fuel\core\classes\arr.php on line 36
Error - 2012-12-03 10:13:45 --> Error - Undefined class constant 'post' in L:\Local Server\sites\sandbox\projet-web\fuel\app\classes\controller\products.php on line 99
Error - 2012-12-03 10:38:06 --> Error - Unsupported operand types in L:\Local Server\sites\sandbox\projet-web\fuel\app\classes\controller\products.php on line 99
Error - 2012-12-03 11:00:20 --> 8 - Undefined variable: current_user in L:\Local Server\sites\sandbox\projet-web\fuel\app\classes\controller\products.php on line 116
Error - 2012-12-03 11:35:17 --> 8 - Undefined variable: sub_total in L:\Local Server\sites\sandbox\projet-web\fuel\app\views\products\order_confirmation.php on line 53
Error - 2012-12-03 14:10:26 --> Error - The requested view could not be found: products/buy in L:\Local Server\sites\sandbox\projet-web\fuel\core\classes\view.php on line 381
Error - 2012-12-03 17:57:04 --> 8 - Undefined variable: order_id in L:\Local Server\sites\sandbox\projet-web\fuel\app\views\layouts\emails\invoice.php on line 4
Error - 2012-12-03 17:57:54 --> 8 - Undefined variable: order_id in L:\Local Server\sites\sandbox\projet-web\fuel\app\views\layouts\emails\invoice.php on line 4
Error - 2012-12-03 17:57:57 --> 8 - Undefined variable: order_id in L:\Local Server\sites\sandbox\projet-web\fuel\app\views\layouts\emails\invoice.php on line 4
Error - 2012-12-03 17:57:59 --> 8 - Undefined variable: order_id in L:\Local Server\sites\sandbox\projet-web\fuel\app\views\layouts\emails\invoice.php on line 4
Error - 2012-12-03 17:58:08 --> 8 - Undefined variable: order_id in L:\Local Server\sites\sandbox\projet-web\fuel\app\views\layouts\emails\invoice.php on line 4
Error - 2012-12-03 17:58:10 --> 8 - Undefined variable: order_id in L:\Local Server\sites\sandbox\projet-web\fuel\app\views\layouts\emails\invoice.php on line 4
Error - 2012-12-03 17:59:26 --> 8 - Undefined variable: order_id in L:\Local Server\sites\sandbox\projet-web\fuel\app\views\layouts\emails\invoice.php on line 4
Error - 2012-12-03 17:59:29 --> 8 - Undefined variable: order_id in L:\Local Server\sites\sandbox\projet-web\fuel\app\views\layouts\emails\invoice.php on line 4
Error - 2012-12-03 19:16:46 --> 8 - Undefined variable: order_id in L:\Local Server\sites\sandbox\projet-web\fuel\app\views\layouts\emails\invoice.php on line 4
Error - 2012-12-03 19:18:43 --> 8 - Trying to get property of non-object in L:\Local Server\sites\sandbox\projet-web\fuel\app\views\layouts\emails\invoice.php on line 28
Error - 2012-12-03 19:24:00 --> 8 - Trying to get property of non-object in L:\Local Server\sites\sandbox\projet-web\fuel\app\views\layouts\emails\invoice.php on line 28
Error - 2012-12-03 19:24:22 --> 8 - Undefined index: price in L:\Local Server\sites\sandbox\projet-web\fuel\app\views\layouts\emails\invoice.php on line 28
Error - 2012-12-03 19:24:54 --> 8 - Undefined index: price in L:\Local Server\sites\sandbox\projet-web\fuel\app\views\layouts\emails\invoice.php on line 28
