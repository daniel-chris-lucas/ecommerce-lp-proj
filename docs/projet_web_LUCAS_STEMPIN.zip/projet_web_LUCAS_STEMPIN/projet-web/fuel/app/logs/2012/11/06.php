<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

Error - 2012-11-06 13:32:16 --> 8 - Trying to get property of non-object in L:\Local Server\sites\sandbox\projet-web\fuel\app\views\admin\products\edit.php on line 1
Error - 2012-11-06 13:33:46 --> 8 - Trying to get property of non-object in L:\Local Server\sites\sandbox\projet-web\fuel\app\views\admin\products\edit.php on line 1
Error - 2012-11-06 13:36:13 --> Error - Property "category" not found for Model_Product. in L:\Local Server\sites\sandbox\projet-web\fuel\packages\orm\classes\model.php on line 902
Error - 2012-11-06 13:41:33 --> 8 - Trying to get property of non-object in L:\Local Server\sites\sandbox\projet-web\fuel\app\views\admin\products\edit.php on line 1
Error - 2012-11-06 14:00:54 --> 8 - Trying to get property of non-object in L:\Local Server\sites\sandbox\projet-web\fuel\app\views\admin\products\edit.php on line 1
Error - 2012-11-06 14:17:52 --> Error - Property "image" not found for Model_Product. in L:\Local Server\sites\sandbox\projet-web\fuel\packages\orm\classes\model.php on line 902
Error - 2012-11-06 14:22:37 --> 8 - Trying to get property of non-object in L:\Local Server\sites\sandbox\projet-web\fuel\app\views\admin\products\edit.php on line 1
Error - 2012-11-06 14:23:58 --> 8 - Undefined variable: config in L:\Local Server\sites\sandbox\projet-web\fuel\app\classes\controller\admin\products.php on line 99
Error - 2012-11-06 15:12:37 --> Error - Call to undefined function Fuel\Core\finfo_open() in L:\Local Server\sites\sandbox\projet-web\fuel\core\classes\upload.php on line 341
Error - 2012-11-06 15:14:24 --> Error - Call to undefined function Fuel\Core\finfo_open() in L:\Local Server\sites\sandbox\projet-web\fuel\core\classes\upload.php on line 341
Error - 2012-11-06 15:55:48 --> Error - Property "image_alt" not found for Model_Product. in L:\Local Server\sites\sandbox\projet-web\fuel\packages\orm\classes\model.php on line 902
Error - 2012-11-06 15:57:54 --> Error - Undefined class constant 'get_files' in L:\Local Server\sites\sandbox\projet-web\fuel\app\classes\controller\admin\products.php on line 109
Error - 2012-11-06 20:19:30 --> 8 - Use of undefined constant i - assumed 'i' in L:\Local Server\sites\sandbox\projet-web\fuel\app\views\admin\products\edit.php on line 36
Error - 2012-11-06 20:19:40 --> 8 - Undefined offset: 0 in L:\Local Server\sites\sandbox\projet-web\fuel\app\views\admin\products\edit.php on line 36
Error - 2012-11-06 20:19:51 --> 4096 - Object of class Model_Image could not be converted to string in L:\Local Server\sites\sandbox\projet-web\fuel\app\views\admin\products\edit.php on line 36
Error - 2012-11-06 20:20:01 --> 8 - Undefined offset: 2 in L:\Local Server\sites\sandbox\projet-web\fuel\app\views\admin\products\edit.php on line 36
Error - 2012-11-06 20:20:48 --> 4096 - Object of class Model_Image could not be converted to string in L:\Local Server\sites\sandbox\projet-web\fuel\app\views\admin\products\edit.php on line 36
Error - 2012-11-06 20:20:58 --> 8 - Undefined offset: 2 in L:\Local Server\sites\sandbox\projet-web\fuel\app\views\admin\products\edit.php on line 36
