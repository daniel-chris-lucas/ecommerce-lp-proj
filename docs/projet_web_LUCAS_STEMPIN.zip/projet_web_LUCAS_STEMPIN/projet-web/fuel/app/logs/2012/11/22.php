<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

Error - 2012-11-22 14:40:51 --> Parsing Error - syntax error, unexpected ')', expecting ',' or ';' in L:\Local Server\sites\sandbox\projet-web\fuel\app\classes\model\user.php on line 47
