<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

Error - 2012-10-29 22:43:31 --> Error - Could not find asset: admin.css in L:\Local Server\sites\sandbox\projet-web\fuel\core\classes\asset\instance.php on line 248
Error - 2012-10-29 23:16:41 --> 8 - Undefined variable: moderator_id in L:\Local Server\sites\sandbox\projet-web\fuel\app\views\layouts\template.php on line 72
Error - 2012-10-29 23:21:50 --> 8 - Undefined property: Controller_Home::$moderator_id in L:\Local Server\sites\sandbox\projet-web\fuel\app\classes\controller\base.php on line 39
