<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

Error - 2012-12-13 22:08:56 --> 8 - Undefined variable: categories in L:\Local Server\sites\sandbox\projet-web\fuel\app\views\layouts\template.php on line 71
