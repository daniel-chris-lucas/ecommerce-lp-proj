<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

Error - 2012-11-27 15:25:09 --> 8 - Undefined variable: current_user in L:\Local Server\sites\sandbox\projet-web\fuel\app\classes\controller\products.php on line 8
Error - 2012-11-27 15:25:21 --> 4096 - Object of class Model_User could not be converted to string in L:\Local Server\sites\sandbox\projet-web\fuel\app\classes\controller\products.php on line 8
Error - 2012-11-27 15:59:51 --> Error - Class 'Model_Comment' not found in L:\Local Server\sites\sandbox\projet-web\fuel\app\classes\controller\products.php on line 45
Error - 2012-11-27 16:00:25 --> Error - SQLSTATE[42S22]: Column not found: 1054 Unknown column 't0.desc' in 'order clause' with query: "SELECT `t0`.`id` AS `t0_c0`, `t0`.`user_id` AS `t0_c1`, `t0`.`product_id` AS `t0_c2`, `t0`.`note` AS `t0_c3`, `t0`.`description` AS `t0_c4`, `t0`.`created_at` AS `t0_c5`, `t0`.`updated_at` AS `t0_c6` FROM `ratings` AS `t0` ORDER BY `t0`.`created_at` ASC, `t0`.`desc` ASC" in L:\Local Server\sites\sandbox\projet-web\fuel\core\classes\database\pdo\connection.php on line 175
Error - 2012-11-27 16:12:08 --> Error - Property "user" not found for Model_Rating. in L:\Local Server\sites\sandbox\projet-web\fuel\packages\orm\classes\model.php on line 902
