<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

Error - 2012-11-21 11:35:47 --> Error - Invalid Model instance added to relations in this model. in L:\Local Server\sites\sandbox\projet-web\fuel\packages\orm\classes\belongsto.php on line 114
Error - 2012-11-21 11:39:23 --> Error - Invalid Model instance added to relations in this model. in L:\Local Server\sites\sandbox\projet-web\fuel\packages\orm\classes\belongsto.php on line 114
Error - 2012-11-21 15:39:05 --> 8 - Trying to get property of non-object in L:\Local Server\sites\sandbox\projet-web\fuel\app\classes\controller\products.php on line 14
Error - 2012-11-21 15:39:05 --> 8 - Trying to get property of non-object in L:\Local Server\sites\sandbox\projet-web\fuel\app\classes\controller\products.php on line 14
Error - 2012-11-21 15:39:05 --> 8 - Trying to get property of non-object in L:\Local Server\sites\sandbox\projet-web\fuel\app\classes\controller\products.php on line 14
Error - 2012-11-21 15:39:05 --> 8 - Trying to get property of non-object in L:\Local Server\sites\sandbox\projet-web\fuel\app\classes\controller\products.php on line 14
Error - 2012-11-21 15:40:16 --> 8 - Trying to get property of non-object in L:\Local Server\sites\sandbox\projet-web\fuel\app\classes\controller\products.php on line 14
Error - 2012-11-21 15:40:33 --> 8 - Trying to get property of non-object in L:\Local Server\sites\sandbox\projet-web\fuel\app\classes\controller\products.php on line 14
Error - 2012-11-21 16:55:05 --> 8 - Undefined variable: img in L:\Local Server\sites\sandbox\projet-web\fuel\app\views\products\view.php on line 8
Error - 2012-11-21 19:10:19 --> Error - Call to undefined function calculate_height() in L:\Local Server\sites\sandbox\projet-web\fuel\app\views\products\view.php on line 22
Error - 2012-11-21 19:11:44 --> Error - Call to undefined function calculate_height() in L:\Local Server\sites\sandbox\projet-web\fuel\app\views\products\view.php on line 22
