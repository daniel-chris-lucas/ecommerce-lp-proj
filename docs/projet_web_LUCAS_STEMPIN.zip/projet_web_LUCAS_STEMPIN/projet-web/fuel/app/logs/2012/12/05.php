<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

Error - 2012-12-05 10:54:25 --> 8 - Undefined variable: order in L:\Local Server\sites\sandbox\projet-web\fuel\app\views\layouts\template.php on line 80
Error - 2012-12-05 14:36:49 --> Error - Property "orderproducts" not found for Model_Order. in L:\Local Server\sites\sandbox\projet-web\fuel\packages\orm\classes\model.php on line 902
Error - 2012-12-05 15:34:43 --> 8 - Undefined variable: sub_total in L:\Local Server\sites\sandbox\projet-web\fuel\app\views\users\orders.php on line 27
Error - 2012-12-05 15:37:28 --> 8 - Undefined variable: order in L:\Local Server\sites\sandbox\projet-web\fuel\app\classes\controller\products.php on line 226
