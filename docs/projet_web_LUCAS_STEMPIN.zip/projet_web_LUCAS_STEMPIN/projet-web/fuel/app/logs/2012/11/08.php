<?php defined('COREPATH') or exit('No direct script access allowed'); ?>

Error - 2012-11-08 08:29:45 --> 2 - Missing argument 1 for Fuel\Core\Image_Gd::save(), called in L:\Local Server\sites\sandbox\projet-web\fuel\app\classes\controller\admin\products.php on line 133 and defined in L:\Local Server\sites\sandbox\projet-web\fuel\core\classes\image\gd.php on line 286
Error - 2012-11-08 10:59:06 --> 8 - Undefined offset: 1 in L:\Local Server\sites\sandbox\projet-web\fuel\app\views\admin\products\edit.php on line 3
Error - 2012-11-08 15:24:22 --> 8 - Undefined offset: 2 in L:\Local Server\sites\sandbox\projet-web\fuel\app\views\admin\products\edit.php on line 53
Error - 2012-11-08 15:39:53 --> Parsing Error - syntax error, unexpected '}' in L:\Local Server\sites\sandbox\projet-web\fuel\app\classes\controller\admin\products.php on line 191
Error - 2012-11-08 15:46:47 --> 8 - Trying to get property of non-object in L:\Local Server\sites\sandbox\projet-web\fuel\app\classes\controller\admin\products.php on line 166
Error - 2012-11-08 15:48:07 --> 8 - Trying to get property of non-object in L:\Local Server\sites\sandbox\projet-web\fuel\app\classes\controller\admin\products.php on line 166
Error - 2012-11-08 15:48:40 --> 8 - Trying to get property of non-object in L:\Local Server\sites\sandbox\projet-web\fuel\app\classes\controller\admin\products.php on line 166
Error - 2012-11-08 15:50:08 --> 8 - Trying to get property of non-object in L:\Local Server\sites\sandbox\projet-web\fuel\app\classes\controller\admin\products.php on line 166
