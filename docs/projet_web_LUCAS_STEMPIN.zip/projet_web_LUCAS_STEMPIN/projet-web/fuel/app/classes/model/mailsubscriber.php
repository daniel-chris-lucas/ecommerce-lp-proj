<?php

class Model_Mailsubscriber extends \Orm\Model
{
	protected static $_properties = array(
		'id',
		'user_id'
	);

}
