<?php

class Model_Role extends \Orm\Model
{
	protected static $_properties = array(
		'id',
		'name'
	);
}
