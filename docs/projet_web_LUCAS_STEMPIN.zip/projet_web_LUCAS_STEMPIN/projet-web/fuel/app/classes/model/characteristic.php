<?php

class Model_Characteristic extends \Orm\Model
{
	protected static $_properties = array(
		'id',
		'name',
		'value',
		'product_id'
	);
}
