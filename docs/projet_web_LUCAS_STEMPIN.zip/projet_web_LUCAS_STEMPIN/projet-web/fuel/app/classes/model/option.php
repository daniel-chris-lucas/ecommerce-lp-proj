<?php

class Model_Option extends \Orm\Model
{
	protected static $_properties = array(
		'id',
		'name',
		'value'
	);

}
