<h2>Dashboard</h2>

<p>Here will be some fascinating stats and info when the app is finished :)</p>