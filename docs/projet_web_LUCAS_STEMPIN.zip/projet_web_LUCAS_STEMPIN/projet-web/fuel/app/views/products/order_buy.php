<div class="title_bg">
    <h2 class="title">Order Complete</h2>
</div>

<p>
	Thank you for purchasing products from our store.<br>
	You will shortly receive an invoice by email.
</p>

<p>
	*Note: As this is a demo application, products cannot really be purchased from the site.
</p>

<p>
	<a href="<?= Uri::base() ?>" class="btn btn-primary">Return to store</a>
</p>